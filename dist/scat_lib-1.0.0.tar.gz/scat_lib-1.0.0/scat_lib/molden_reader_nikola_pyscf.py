"""
Compatibility wrapper for scat_lib.pyscf_scat.molden_reader_nikola_pyscf
"""
from .pyscf_scat.molden_reader_nikola_pyscf import *

