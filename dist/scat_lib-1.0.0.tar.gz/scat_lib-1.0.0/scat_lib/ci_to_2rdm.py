"""
Compatibility wrapper for scat_lib.pyscf_scat.ci_to_2rdm
"""
from .pyscf_scat.ci_to_2rdm import *

