"""
Compatibility wrapper for scat_lib.pyscf_scat.reduced_ci
"""
from .pyscf_scat.reduced_ci import *

