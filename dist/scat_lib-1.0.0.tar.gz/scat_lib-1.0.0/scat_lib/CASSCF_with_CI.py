"""
Compatibility wrapper for scat_lib.pyscf_scat.CASSCF_with_CI
"""
from .pyscf_scat.CASSCF_with_CI import *

