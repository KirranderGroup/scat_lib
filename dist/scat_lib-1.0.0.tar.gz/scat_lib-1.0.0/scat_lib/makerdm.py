"""
Compatibility wrapper for scat_lib.pyscf_scat.makerdm
"""
from .pyscf_scat.makerdm import *

