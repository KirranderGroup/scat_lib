from __future__ import annotations
import math
PI = math.pi
# Bohr radius in Å (CODATA 2018)
A0_ANG = 0.529177210903
