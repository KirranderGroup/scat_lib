"""
Test cases for ci_to_2rdm module.
"""

import pytest
import numpy as np
from unittest.mock import Mock, patch, mock_open


class TestCITo2RDM:
    """Test cases for CI to 2RDM functionality."""
    
    @patch('builtins.open', new_callable=mock_open)
    @patch('pyscf.fci')
    def test_write_ci_file_basic(self, mock_fci, mock_file):
        """Test basic write_ci_file functionality."""
        # Mock FCI components
        mock_occslst = np.array([[0, 1], [0, 2], [1, 2]])
        mock_fci.cistring.gen_occslst.return_value = mock_occslst
        
        # Mock CASSCF object
        mock_casscf = Mock()
        mock_casscf.ci = np.array([[0.8, 0.1], [0.2, 0.3]])
        mock_casscf.fcisolver = Mock()
        mock_casscf.fcisolver.large_ci = Mock()
        
        file_name = 'test_ci'
        nelec = (2, 2)
        ncas = 4
        
        from scat_lib.ci_to_2rdm import write_ci_file
        from scat_lib.ci_to_2rdm import write_ci_file
        write_ci_file(file_name, mock_casscf, nelec, ncas)
        
        # Check that files were opened for writing
        mock_file.assert_any_call(f'{file_name}_ci.txt', 'w')
        mock_file.assert_any_call(f'{file_name}_ci_large.txt', 'w')
        
        # Check that FCI functions were called
        mock_fci.cistring.gen_occslst.assert_called()
    
    @patch('builtins.open', new_callable=mock_open)
    @patch('pyscf.fci')
    def test_write_ci_file_with_tolerance(self, mock_fci, mock_file):
        """Test write_ci_file with custom tolerance."""
        # Mock FCI components
        mock_occslst = np.array([[0, 1], [0, 2]])
        mock_fci.cistring.gen_occslst.return_value = mock_occslst
        
        # Mock CASSCF object
        mock_casscf = Mock()
        mock_casscf.ci = np.array([[0.9, 0.01], [0.001, 0.1]])
        mock_casscf.fcisolver = Mock()
        mock_casscf.fcisolver.large_ci = Mock()
        
        file_name = 'test_ci_tol'
        nelec = (2, 2)
        ncas = 4
        tol = 1e-3
        
        write_ci_file(file_name, mock_casscf, nelec, ncas, tol=tol)
        
        # Verify files were created
        mock_file.assert_any_call(f'{file_name}_ci.txt', 'w')
        mock_file.assert_any_call(f'{file_name}_ci_large.txt', 'w')
    
    @patch('builtins.open', new_callable=mock_open)
    @patch('pyscf.fci')
    def test_write_ci_file_different_active_spaces(self, mock_fci, mock_file):
        """Test write_ci_file with different active space sizes."""
        test_cases = [
            {'ncas': 2, 'nelec': (1, 1)},
            {'ncas': 4, 'nelec': (2, 2)},
            {'ncas': 6, 'nelec': (3, 3)}
        ]
        
        for i, case in enumerate(test_cases):
            # Mock FCI components for each case
            mock_occslst = np.array([[0], [1]])  # Simplified
            mock_fci.cistring.gen_occslst.return_value = mock_occslst
            
            # Mock CASSCF object
            mock_casscf = Mock()
            mock_casscf.ci = np.array([[0.8, 0.2]])
            mock_casscf.fcisolver = Mock()
            mock_casscf.fcisolver.large_ci = Mock()
            
            file_name = f'test_ci_{i}'
            write_ci_file(file_name, mock_casscf, case['nelec'], case['ncas'])
        
        # Should have been called for each test case
        assert mock_file.call_count >= len(test_cases) * 2  # 2 files per case
    
    def test_ci_coefficients_validation(self):
        """Test CI coefficients validation."""
        # Test different CI coefficient matrices
        test_matrices = [
            np.array([[1.0, 0.0], [0.0, 0.0]]),  # Single determinant
            np.array([[0.7, 0.3], [0.5, 0.5]]),  # Multi-configuration
            np.array([[0.9, 0.1, 0.05], [0.2, 0.3, 0.4], [0.1, 0.2, 0.3]])  # Larger
        ]
        
        for matrix in test_matrices:
            assert matrix.ndim == 2
            assert matrix.shape[0] > 0
            assert matrix.shape[1] > 0
            # CI coefficients should be real numbers
            assert np.all(np.isreal(matrix))
    
    def test_tolerance_parameter(self):
        """Test tolerance parameter validation."""
        valid_tolerances = [1e-3, 1e-4, 1e-5, 5e-5, 1e-6]
        
        for tol in valid_tolerances:
            assert isinstance(tol, float)
            assert tol > 0
            assert tol < 1
    
    def test_nelec_parameter_formats(self):
        """Test different nelec parameter formats."""
        valid_nelec = [
            (1, 1),  # Tuple format
            (2, 2),
            (3, 3),
            (2, 1),  # Different alpha/beta
            4        # Integer format (total electrons)
        ]
        
        for nelec in valid_nelec:
            if isinstance(nelec, tuple):
                assert len(nelec) == 2
                assert all(isinstance(n, int) for n in nelec)
                assert all(n >= 0 for n in nelec)
            else:
                assert isinstance(nelec, int)
                assert nelec >= 0
    
    def test_ncas_parameter(self):
        """Test ncas parameter validation."""
        valid_ncas = [2, 4, 6, 8, 10]
        
        for ncas in valid_ncas:
            assert isinstance(ncas, int)
            assert ncas > 0
            assert ncas % 2 == 0  # Usually even for closed-shell systems
    
    @patch('builtins.open', new_callable=mock_open)
    @patch('pyscf.fci')
    def test_file_naming_convention(self, mock_fci, mock_file):
        """Test file naming convention."""
        # Mock FCI components
        mock_occslst = np.array([[0, 1]])
        mock_fci.cistring.gen_occslst.return_value = mock_occslst
        
        # Mock CASSCF object
        mock_casscf = Mock()
        mock_casscf.ci = np.array([[0.8]])
        mock_casscf.fcisolver = Mock()
        mock_casscf.fcisolver.large_ci = Mock()
        
        test_names = ['test', 'molecule_1', 'casscf_calc', 'h2o_ci']
        
        for file_name in test_names:
            write_ci_file(file_name, mock_casscf, (2, 2), 4)
            
            # Check expected file names
            expected_calls = [
                f'{file_name}_ci.txt',
                f'{file_name}_ci_large.txt'
            ]
            
            for expected_file in expected_calls:
                mock_file.assert_any_call(expected_file, 'w')