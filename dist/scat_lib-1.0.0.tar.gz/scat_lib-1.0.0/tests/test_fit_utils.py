"""
Test cases for fit_utils module.
"""

import pytest
import numpy as np
from unittest.mock import Mock, patch, mock_open


class TestFitUtils:
    """Test cases for fitting utilities."""
    
    @patch('scat_lib.fit_utils.os.system')
    @patch('scat_lib.fit_utils.np.loadtxt')
    @patch('scat_lib.fit_utils.update_options')
    @patch('scat_lib.fit_utils.save_rdm')
    @patch('scat_lib.fit_utils.update_ci_coeffs')
    @patch('scat_lib.fit_utils.read_ci_file')
    def test_fitting_basic(self, mock_read_ci, mock_update_ci, mock_save_rdm, 
                          mock_update_options, mock_loadtxt, mock_system):
        """Test basic fitting functionality."""
        # Setup mocks
        mock_read_ci.return_value = (np.array([1, 2]), np.array([1, 2]), np.array([0.8, 0.2]))
        mock_loadtxt.return_value = np.array([[1, 10], [2, 20], [3, 30]])
        
        # Mock inputs
        x = np.array([0.8, 0.6])
        mock_casscf = Mock()
        ref = np.array([[1, 5], [2, 10], [3, 15]])
        hf_dat = np.array([[1, 2], [2, 4], [3, 6]])
        name = 'test_fit'
        
        from scat_lib.fit_utils import fitting
        result = fitting(x, mock_casscf, ref, hf_dat, name)
        
        # Verify function calls
        mock_read_ci.assert_called_once()
        mock_update_ci.assert_called_once()
        mock_save_rdm.assert_called_once_with(mock_casscf, name)
        mock_update_options.assert_called_once_with(name)
        mock_system.assert_called_once()
        mock_loadtxt.assert_called_once()
        
        # Result should be a float (cost)
        assert isinstance(result, (int, float))
    
    @patch('scat_lib.fit_utils.os.system')
    @patch('scat_lib.fit_utils.np.loadtxt')
    @patch('scat_lib.fit_utils.update_options')
    @patch('scat_lib.fit_utils.save_rdm')
    @patch('scat_lib.fit_utils.update_ci_coeffs')
    @patch('scat_lib.fit_utils.read_ci_file')
    def test_fitting_normalization(self, mock_read_ci, mock_update_ci, mock_save_rdm,
                                  mock_update_options, mock_loadtxt, mock_system):
        """Test that CI coefficients are properly normalized."""
        # Setup mocks
        mock_read_ci.return_value = (np.array([1, 2]), np.array([1, 2]), np.array([0.8, 0.2]))
        mock_loadtxt.return_value = np.array([[1, 10], [2, 20]])
        
        # Test normalization
        x = np.array([3.0, 4.0])  # Not normalized
        mock_casscf = Mock()
        ref = np.array([[1, 5], [2, 10]])
        hf_dat = np.array([[1, 2], [2, 4]])
        
        fitting(x, mock_casscf, ref, hf_dat)
        
        # Check that update_ci_coeffs was called with normalized coefficients
        mock_update_ci.assert_called_once()
        call_args = mock_update_ci.call_args[0]
        normalized_x = call_args[2]  # Third argument should be normalized x
        
        # Verify normalization: sum of squares should be 1
        np.testing.assert_almost_equal(np.sum(normalized_x**2), 1.0)
    
    @patch('scat_lib.fit_utils.os.system')
    @patch('scat_lib.fit_utils.np.loadtxt')
    @patch('scat_lib.fit_utils.update_options')
    @patch('scat_lib.fit_utils.save_rdm')
    @patch('scat_lib.fit_utils.update_ci_coeffs')
    @patch('scat_lib.fit_utils.read_ci_file')
    def test_fitting_cost_calculation(self, mock_read_ci, mock_update_ci, mock_save_rdm,
                                     mock_update_options, mock_loadtxt, mock_system):
        """Test cost calculation in fitting."""
        # Setup mocks with specific data
        mock_read_ci.return_value = (np.array([1, 2]), np.array([1, 2]), np.array([0.8, 0.2]))
        
        # Mock calculated intensities
        calc_data = np.array([[1, 10], [2, 20], [3, 30]])
        mock_loadtxt.return_value = calc_data
        
        # Input data
        x = np.array([0.8, 0.6])
        mock_casscf = Mock()
        ref = np.array([[1, 5], [2, 15], [3, 25]])    # Reference intensities
        hf_dat = np.array([[1, 2], [2, 4], [3, 6]])   # HF intensities
        
        result = fitting(x, mock_casscf, ref, hf_dat)
        
        # Cost should be calculated based on difference between target and fit
        assert isinstance(result, (int, float))
        assert result >= 0  # Cost should be non-negative
    
    def test_fitting_input_validation(self):
        """Test input validation for fitting function."""
        # Test array shapes and types
        valid_x = np.array([0.8, 0.6])
        valid_ref = np.array([[1, 5], [2, 10]])
        valid_hf_dat = np.array([[1, 2], [2, 4]])
        
        # Check that inputs are numpy arrays
        assert isinstance(valid_x, np.ndarray)
        assert isinstance(valid_ref, np.ndarray)
        assert isinstance(valid_hf_dat, np.ndarray)
        
        # Check shapes
        assert valid_x.ndim == 1
        assert valid_ref.ndim == 2
        assert valid_hf_dat.ndim == 2
        assert valid_ref.shape[1] == 2  # Should have q and I columns
        assert valid_hf_dat.shape[1] == 2
    
    @patch('scat_lib.fit_utils.os.system')
    @patch('scat_lib.fit_utils.np.loadtxt')
    @patch('scat_lib.fit_utils.update_options')
    @patch('scat_lib.fit_utils.save_rdm')
    @patch('scat_lib.fit_utils.update_ci_coeffs')
    @patch('scat_lib.fit_utils.read_ci_file')
    def test_fitting_with_different_names(self, mock_read_ci, mock_update_ci, mock_save_rdm,
                                         mock_update_options, mock_loadtxt, mock_system):
        """Test fitting with different output names."""
        # Setup mocks
        mock_read_ci.return_value = (np.array([1]), np.array([1]), np.array([1.0]))
        mock_loadtxt.return_value = np.array([[1, 10]])
        
        names = ['fit1', 'test_molecule', 'optimization_run']
        
        for name in names:
            x = np.array([1.0])
            mock_casscf = Mock()
            ref = np.array([[1, 5]])
            hf_dat = np.array([[1, 2]])
            
            fitting(x, mock_casscf, ref, hf_dat, name)
            
            # Check that save_rdm and update_options were called with correct name
            mock_save_rdm.assert_called_with(mock_casscf, name)
            mock_update_options.assert_called_with(name)
            
            # Check that loadtxt was called with correct filename
            expected_filename = f'total_{name}.dat'
            mock_loadtxt.assert_called_with(expected_filename)
    
    def test_intensity_data_format(self):
        """Test expected format of intensity data."""
        # Test reference and HF data format
        sample_ref = np.array([[0.1, 100], [0.2, 90], [0.3, 80]])
        sample_hf = np.array([[0.1, 50], [0.2, 45], [0.3, 40]])
        
        # Should have 2 columns: q-values and intensities
        assert sample_ref.shape[1] == 2
        assert sample_hf.shape[1] == 2
        
        # q-values should be positive and increasing
        assert np.all(sample_ref[:, 0] > 0)
        assert np.all(sample_hf[:, 0] > 0)
        assert np.all(np.diff(sample_ref[:, 0]) >= 0)
        assert np.all(np.diff(sample_hf[:, 0]) >= 0)
    
    @patch('scat_lib.fit_utils.os.system')
    def test_external_program_execution(self, mock_system):
        """Test that external scattering program is called."""
        with patch('scat_lib.fit_utils.read_ci_file'), \
             patch('scat_lib.fit_utils.update_ci_coeffs'), \
             patch('scat_lib.fit_utils.save_rdm'), \
             patch('scat_lib.fit_utils.update_options'), \
             patch('scat_lib.fit_utils.np.loadtxt'):
            
            x = np.array([1.0])
            mock_casscf = Mock()
            ref = np.array([[1, 5]])
            hf_dat = np.array([[1, 2]])
            
            fitting(x, mock_casscf, ref, hf_dat)
            
            # Verify that external program was called
            mock_system.assert_called_once()
            call_args = mock_system.call_args[0][0]
            assert 'Main.exe' in call_args