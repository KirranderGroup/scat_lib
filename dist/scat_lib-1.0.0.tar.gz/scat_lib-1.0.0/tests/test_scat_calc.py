"""
Test cases for scat_calc module.
"""

import pytest
import numpy as np
from unittest.mock import Mock, patch, mock_open
from scat_lib.scat_calc import prepare_files, types


class TestScatCalc:
    """Test cases for scattering calculation functionality."""
    
    def test_types_dictionary(self):
        """Test that scattering types dictionary is properly defined."""
        expected_types = {
            'total': '1', 
            'elastic': '2',
            'total_aligned': '3',
            'elastic_aligned': '4',
            'total_electron': '5',
            'elastic_electron': '6',
            'total_j2': '7',
            'elastic_j2': '8',
            'resolved_cms': '9'
        }
        
        assert types == expected_types
        assert len(types) == 9
        assert all(isinstance(v, str) for v in types.values())
    
    def test_types_coverage(self):
        """Test that all expected scattering types are covered."""
        required_types = [
            'total', 'elastic', 'total_aligned', 'elastic_aligned',
            'total_electron', 'elastic_electron', 'total_j2', 
            'elastic_j2', 'resolved_cms'
        ]
        
        for req_type in required_types:
            assert req_type in types
    
    @patch('builtins.open', new_callable=mock_open)
    def test_prepare_files_basic(self, mock_file):
        """Test basic prepare_files functionality."""
        file_name = 'test_output'
        one_rdm_file = '1rdm_test.txt'
        two_rdm_file = '2rdm_test.txt'
        molden_file = 'test.molden'
        
        # Mock file operations
        prepare_files(
            file_name=file_name,
            one_rdm_file=one_rdm_file,
            two_rdm_file=two_rdm_file,
            molden_file=molden_file
        )
        
        # Check that options file was created
        mock_file.assert_called()
    
    @patch('builtins.open', new_callable=mock_open)
    def test_prepare_files_with_custom_parameters(self, mock_file):
        """Test prepare_files with custom parameters."""
        file_name = 'custom_output'
        one_rdm_file = '1rdm_custom.txt'
        two_rdm_file = '2rdm_custom.txt'
        molden_file = 'custom.molden'
        
        prepare_files(
            file_name=file_name,
            one_rdm_file=one_rdm_file,
            two_rdm_file=two_rdm_file,
            molden_file=molden_file,
            type='elastic',
            q_range=(0.1, 100),
            q_points=500,
            cutoffcentre=1e-3,
            cutoffz=1e-15,
            cutoffmd=1e-15
        )
        
        mock_file.assert_called()
    
    @patch('builtins.open', new_callable=mock_open)
    def test_prepare_files_different_types(self, mock_file):
        """Test prepare_files with different scattering types."""
        base_args = {
            'file_name': 'test',
            'one_rdm_file': '1rdm.txt',
            'two_rdm_file': '2rdm.txt',
            'molden_file': 'test.molden'
        }
        
        # Test different scattering types
        for scat_type in types.keys():
            prepare_files(**base_args, type=scat_type)
        
        # Should have been called for each type
        assert mock_file.call_count >= len(types)
    
    def test_q_range_validation(self):
        """Test q_range parameter validation."""
        # Valid q_range should be a tuple of two numbers
        valid_ranges = [
            (0.01, 100),
            (1e-10, 250),
            (0.1, 50.5)
        ]
        
        for q_range in valid_ranges:
            assert len(q_range) == 2
            assert q_range[0] < q_range[1]
            assert all(isinstance(x, (int, float)) for x in q_range)
    
    def test_q_points_validation(self):
        """Test q_points parameter validation."""
        valid_q_points = [100, 500, 1000, 2000]
        
        for q_points in valid_q_points:
            assert isinstance(q_points, int)
            assert q_points > 0
    
    def test_cutoff_parameters_validation(self):
        """Test cutoff parameters validation."""
        cutoff_params = {
            'cutoffcentre': [1e-2, 1e-3, 1e-4],
            'cutoffz': [1e-20, 1e-15, 1e-10],
            'cutoffmd': [1e-20, 1e-15, 1e-10]
        }
        
        for param_name, values in cutoff_params.items():
            for value in values:
                assert isinstance(value, float)
                assert value > 0
                assert value < 1
    
    def test_state_parameters(self):
        """Test state parameters validation."""
        state_params = ['state1', 'state2', 'state3']
        
        for state in state_params:
            # Default value should be 1
            default_value = 1
            assert isinstance(default_value, int)
            assert default_value >= 1
    
    @patch('builtins.open', new_callable=mock_open)
    def test_file_name_handling(self, mock_file):
        """Test different file name formats."""
        test_cases = [
            'simple_name',
            'name_with_underscores',
            'name-with-dashes',
            'nameWithCamelCase'
        ]
        
        base_args = {
            'one_rdm_file': '1rdm.txt',
            'two_rdm_file': '2rdm.txt',
            'molden_file': 'test.molden'
        }
        
        for file_name in test_cases:
            prepare_files(file_name=file_name, **base_args)
        
        # Should have been called for each file name
        assert mock_file.call_count >= len(test_cases)