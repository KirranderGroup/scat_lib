"""
Test cases for rdm_tools module.
"""

import pytest
import numpy as np
from unittest.mock import Mock, patch, mock_open
from scat_lib.rdm_tools import _make_rdm12_on_mo, get_dms, save_rdm


class TestRDMTools:
    """Test cases for RDM tools functionality."""
    
    def test_make_rdm12_on_mo_basic(self):
        """Test basic _make_rdm12_on_mo functionality."""
        ncore, ncas, nmo = 2, 2, 6
        
        # Create simple test matrices
        casdm1 = np.eye(ncas)
        casdm2 = np.zeros((ncas, ncas, ncas, ncas))
        
        dm1, dm2 = _make_rdm12_on_mo(casdm1, casdm2, ncore, ncas, nmo)
        
        # Check dimensions
        assert dm1.shape == (nmo, nmo)
        assert dm2.shape == (nmo, nmo, nmo, nmo)
        
        # Check core electron contributions to dm1
        for i in range(ncore):
            assert dm1[i, i] == 2.0
        
        # Check active space contributions to dm1
        for i in range(ncas):
            assert dm1[ncore + i, ncore + i] == casdm1[i, i]
    
    def test_make_rdm12_on_mo_dimensions(self):
        """Test _make_rdm12_on_mo with different dimensions."""
        ncore, ncas, nmo = 1, 3, 8
        
        casdm1 = np.random.rand(ncas, ncas)
        casdm2 = np.random.rand(ncas, ncas, ncas, ncas)
        
        dm1, dm2 = _make_rdm12_on_mo(casdm1, casdm2, ncore, ncas, nmo)
        
        assert dm1.shape == (nmo, nmo)
        assert dm2.shape == (nmo, nmo, nmo, nmo)
        
        # Check that core electrons have density 2
        assert dm1[0, 0] == 2.0
    
    def test_get_dms_mock(self):
        """Test get_dms function with mocked casscf object."""
        # Create mock casscf object
        mock_casscf = Mock()
        mock_casscf.nelecas = (2, 2)
        mock_casscf.ncas = 4
        mock_casscf.ncore = 2
        mock_casscf.ci = np.array([0.8, 0.6])
        mock_casscf.mo_coeff = np.random.rand(10, 8)
        
        # Mock the fcisolver
        mock_fcisolver = Mock()
        mock_casdm1 = np.eye(4)
        mock_casdm2 = np.zeros((4, 4, 4, 4))
        mock_fcisolver.make_rdm12.return_value = (mock_casdm1, mock_casdm2)
        mock_casscf.fcisolver = mock_fcisolver
        
        dm1, dm2 = get_dms(mock_casscf)
        
        # Check that fcisolver.make_rdm12 was called
        mock_fcisolver.make_rdm12.assert_called_once()
        
        # Check dimensions
        nmo = mock_casscf.mo_coeff.shape[1]
        assert dm1.shape == (nmo, nmo)
        assert dm2.shape == (nmo, nmo, nmo, nmo)
    
    @patch('builtins.open', new_callable=mock_open)
    def test_save_rdm_mock(self, mock_file):
        """Test save_rdm function with mocked file operations."""
        # Create mock casscf object
        mock_casscf = Mock()
        mock_casscf.nelecas = (2, 2)
        mock_casscf.ncas = 2
        mock_casscf.ncore = 1
        mock_casscf.ci = np.array([0.9, 0.1])
        mock_casscf.mo_coeff = np.random.rand(5, 4)
        
        # Mock the fcisolver
        mock_fcisolver = Mock()
        mock_casdm1 = np.array([[0.5, 0.1], [0.1, 0.5]])
        mock_casdm2 = np.zeros((2, 2, 2, 2))
        mock_fcisolver.make_rdm12.return_value = (mock_casdm1, mock_casdm2)
        mock_casscf.fcisolver = mock_fcisolver
        
        name = 'test'
        save_rdm(mock_casscf, name)
        
        # Check that files were opened for writing
        mock_file.assert_any_call(f'1rdm_{name}.txt', 'w')
        mock_file.assert_any_call(f'2rdm_{name}.txt', 'w')
    
    def test_rdm_tools_integration(self):
        """Test integration between different RDM tools functions."""
        ncore, ncas, nmo = 1, 2, 4
        
        # Create test data
        casdm1 = np.array([[0.8, 0.2], [0.2, 0.8]])
        casdm2 = np.zeros((ncas, ncas, ncas, ncas))
        
        dm1, dm2 = _make_rdm12_on_mo(casdm1, casdm2, ncore, ncas, nmo)
        
        # Verify core electron density
        assert dm1[0, 0] == 2.0
        
        # Verify active space density transfer
        np.testing.assert_array_equal(
            dm1[ncore:ncore+ncas, ncore:ncore+ncas], 
            casdm1
        )
        
        # Verify 2RDM active space transfer
        np.testing.assert_array_equal(
            dm2[ncore:ncore+ncas, ncore:ncore+ncas, ncore:ncore+ncas, ncore:ncore+ncas],
            casdm2
        )