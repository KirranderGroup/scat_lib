"""
Simple tests for scat_lib modules without heavy dependencies.
"""

import pytest
import numpy as np
from unittest.mock import Mock, patch


class TestSimpleModuleFunctionality:
    """Simple tests focusing on basic functionality."""
    
    def test_library_imports(self):
        """Test that the library can be imported."""
        import scat_lib
        assert hasattr(scat_lib, '__version__')
        assert scat_lib.__version__ == "0.1.0"
    
    def test_molecule_atom_creation(self):
        """Test basic atom creation."""
        from scat_lib.molecule import Atom
        
        atom = Atom(atmnum=6, x=0.0, y=0.0, z=0.0)
        assert atom.atmnum == 6
        assert atom.symbol == 'C'
        assert atom.x == 0.0
        assert atom.y == 0.0
        assert atom.z == 0.0
    
    def test_molecule_atom_symbols(self):
        """Test atom symbol mapping."""
        from scat_lib.molecule import Atom
        
        # Test common elements
        h_atom = Atom(atmnum=1, x=0.0, y=0.0, z=0.0)
        c_atom = Atom(atmnum=6, x=0.0, y=0.0, z=0.0)
        n_atom = Atom(atmnum=7, x=0.0, y=0.0, z=0.0)
        o_atom = Atom(atmnum=8, x=0.0, y=0.0, z=0.0)
        
        assert h_atom.symbol == 'H'
        assert c_atom.symbol == 'C'
        assert n_atom.symbol == 'N'
        assert o_atom.symbol == 'O'
    
    def test_rdm_tools_basic_function(self):
        """Test basic RDM tools functionality."""
        from scat_lib.rdm_tools import _make_rdm12_on_mo
        
        ncore, ncas, nmo = 1, 2, 4
        casdm1 = np.eye(ncas)
        casdm2 = np.zeros((ncas, ncas, ncas, ncas))
        
        dm1, dm2 = _make_rdm12_on_mo(casdm1, casdm2, ncore, ncas, nmo)
        
        # Check dimensions
        assert dm1.shape == (nmo, nmo)
        assert dm2.shape == (nmo, nmo, nmo, nmo)
        
        # Check core electron contribution
        assert dm1[0, 0] == 2.0
    
    def test_scat_calc_types_dictionary(self):
        """Test scattering calculation types."""
        from scat_lib.scat_calc import types
        
        expected_types = [
            'total', 'elastic', 'total_aligned', 'elastic_aligned',
            'total_electron', 'elastic_electron', 'total_j2', 
            'elastic_j2', 'resolved_cms'
        ]
        
        for expected_type in expected_types:
            assert expected_type in types
            assert isinstance(types[expected_type], str)
    
    def test_module_availability(self):
        """Test that all expected modules are in __all__."""
        import scat_lib
        
        expected_modules = [
            'ci_to_2rdm', 'fit_utils', 'makerdm', 'molecule',
            'molden_reader_nikola_pyscf', 'rdm_tools', 'reduced_ci', 'scat_calc'
        ]
        
        for module in expected_modules:
            assert module in scat_lib.__all__
    
    def test_constants_and_utilities(self):
        """Test constants and utility functions."""
        from scat_lib.molecule import AU2ANG
        
        # Check that constant is reasonable
        assert 0.5 < AU2ANG < 0.6  # Should be around 0.529
    
    def test_atom_mass_setting(self):
        """Test atom mass setting functionality."""
        from scat_lib.molecule import Atom
        
        atom = Atom(atmnum=1, x=0.0, y=0.0, z=0.0)
        atom.set_mass(2.014, 'amu')
        
        assert atom.mass == 2.014
        assert atom.mass_units == 'amu'
    
    def test_rdm_dimension_consistency(self):
        """Test RDM dimension consistency."""
        from scat_lib.rdm_tools import _make_rdm12_on_mo
        
        # Test with different sizes
        test_cases = [
            (1, 2, 4),
            (2, 4, 8),
            (0, 2, 2)  # No core electrons
        ]
        
        for ncore, ncas, nmo in test_cases:
            casdm1 = np.random.rand(ncas, ncas)
            casdm2 = np.random.rand(ncas, ncas, ncas, ncas)
            
            dm1, dm2 = _make_rdm12_on_mo(casdm1, casdm2, ncore, ncas, nmo)
            
            assert dm1.shape == (nmo, nmo)
            assert dm2.shape == (nmo, nmo, nmo, nmo)
    
    def test_numerical_types(self):
        """Test that functions handle numerical types correctly."""
        from scat_lib.molecule import Atom
        
        # Test with different numerical types
        atom1 = Atom(atmnum=1, x=0, y=0, z=0)  # int
        atom2 = Atom(atmnum=1, x=0.0, y=0.0, z=0.0)  # float
        atom3 = Atom(atmnum=1, x=np.float64(0), y=np.float64(0), z=np.float64(0))  # numpy
        
        for atom in [atom1, atom2, atom3]:
            assert atom.atmnum == 1
            assert atom.symbol == 'H'