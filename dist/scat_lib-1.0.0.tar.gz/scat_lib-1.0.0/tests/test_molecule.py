"""
Test cases for molecule module.
"""

import pytest
import numpy as np
from scat_lib.molecule import Atom


class TestAtom:
    """Test cases for the Atom class."""
    
    def test_atom_creation_basic(self):
        """Test basic atom creation."""
        atom = Atom(atmnum=1, x=0.0, y=0.0, z=0.0)
        assert atom.atmnum == 1
        assert atom.x == 0.0
        assert atom.y == 0.0
        assert atom.z == 0.0
        assert atom.charge == 0
        assert atom.xyz_units == 'au'
        assert atom.symbol == 'H'
    
    def test_atom_creation_with_charge(self):
        """Test atom creation with charge."""
        atom = Atom(atmnum=6, x=1.0, y=1.0, z=1.0, charge=1)
        assert atom.atmnum == 6
        assert atom.charge == 1
        assert atom.symbol == 'C'
    
    def test_atom_creation_with_angstrom_units(self):
        """Test atom creation with angstrom units."""
        atom = Atom(atmnum=8, x=0.5, y=0.5, z=0.5, xyz_units='ang')
        assert atom.xyz_units == 'ang'
        assert atom.symbol == 'O'
    
    def test_atom_symbol_mapping(self):
        """Test atom symbol mapping for common elements."""
        # Test a few common elements
        assert Atom.atom_symbol(1) == 'H'
        assert Atom.atom_symbol(6) == 'C'
        assert Atom.atom_symbol(7) == 'N'
        assert Atom.atom_symbol(8) == 'O'
    
    def test_set_mass(self):
        """Test setting atom mass."""
        atom = Atom(atmnum=1, x=0.0, y=0.0, z=0.0)
        atom.set_mass(2.014, 'amu')
        assert atom.mass == 2.014
        assert atom.mass_units == 'amu'
    
    def test_coordinates_access(self):
        """Test coordinate access."""
        x, y, z = 1.5, -2.3, 4.7
        atom = Atom(atmnum=1, x=x, y=y, z=z)
        assert atom.x == x
        assert atom.y == y
        assert atom.z == z


class TestMolecule:
    """Test cases for molecule functionality."""
    
    def test_empty_molecule_creation(self):
        """Test creation of empty molecule list."""
        atoms = []
        assert len(atoms) == 0
    
    def test_simple_molecule_creation(self):
        """Test creation of simple molecule (H2)."""
        atoms = [
            Atom(atmnum=1, x=0.0, y=0.0, z=0.0),
            Atom(atmnum=1, x=0.0, y=0.0, z=1.4)
        ]
        assert len(atoms) == 2
        assert all(atom.symbol == 'H' for atom in atoms)
        assert atoms[1].z == 1.4
    
    def test_water_molecule_creation(self):
        """Test creation of water molecule."""
        atoms = [
            Atom(atmnum=8, x=0.0, y=0.0, z=0.0),      # O
            Atom(atmnum=1, x=1.8, y=0.0, z=0.0),      # H
            Atom(atmnum=1, x=-0.9, y=1.56, z=0.0)     # H
        ]
        assert len(atoms) == 3
        assert atoms[0].symbol == 'O'
        assert atoms[1].symbol == 'H'
        assert atoms[2].symbol == 'H'
        
        # Check geometry
        assert atoms[0].x == 0.0
        assert atoms[1].x == 1.8
        assert atoms[2].y == 1.56