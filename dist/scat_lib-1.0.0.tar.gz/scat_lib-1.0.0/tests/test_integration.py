"""
Integration tests for scat_lib library.
"""

import pytest
import numpy as np
from unittest.mock import Mock, patch
import scat_lib


class TestLibraryIntegration:
    """Integration tests for the scat_lib library."""
    
    def test_library_import(self):
        """Test that the library imports correctly."""
        import scat_lib
        assert hasattr(scat_lib, '__version__')
        assert hasattr(scat_lib, '__author__')
        assert scat_lib.__version__ == "0.1.0"
        assert scat_lib.__author__ == "Patrick Wang"
    
    def test_module_availability(self):
        """Test that all expected modules are available."""
        expected_modules = [
            'ci_to_2rdm',
            'fit_utils',
            'makerdm',
            'molecule',
            'molden_reader_nikola_pyscf',
            'rdm_tools',
            'reduced_ci',
            'scat_calc'
        ]
        
        for module_name in expected_modules:
            assert module_name in scat_lib.__all__
    
    def test_import_error_handling(self):
        """Test that import errors are handled gracefully."""
        # The __init__.py file should handle ImportError exceptions
        # and issue warnings instead of failing completely
        with patch('scat_lib.ci_to_2rdm', side_effect=ImportError("Test error")):
            # This should not raise an exception
            import warnings
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                # The import should still work, just with warnings
                assert len(w) == 0 or any("Could not import" in str(warning.message) for warning in w)
    
    def test_molecule_rdm_workflow(self):
        """Test integration between molecule and RDM tools."""
        from scat_lib.molecule import Atom
        from scat_lib.rdm_tools import _make_rdm12_on_mo
        
        # Create a simple molecule
        atoms = [
            Atom(atmnum=1, x=0.0, y=0.0, z=0.0),
            Atom(atmnum=1, x=0.0, y=0.0, z=1.4)
        ]
        
        # Create simple RDM data
        ncore, ncas, nmo = 1, 2, 4
        casdm1 = np.eye(ncas) * 0.5
        casdm2 = np.zeros((ncas, ncas, ncas, ncas))
        
        dm1, dm2 = _make_rdm12_on_mo(casdm1, casdm2, ncore, ncas, nmo)
        
        # Verify the workflow works
        assert len(atoms) == 2
        assert dm1.shape == (nmo, nmo)
        assert dm2.shape == (nmo, nmo, nmo, nmo)
    
    @patch('scat_lib.fit_utils.os.system')
    @patch('scat_lib.fit_utils.np.loadtxt')
    def test_scattering_calculation_workflow(self, mock_loadtxt, mock_system):
        """Test integration of scattering calculation workflow."""
        from scat_lib.scat_calc import prepare_files, types
        from scat_lib.rdm_tools import save_rdm
        
        # Mock data
        mock_loadtxt.return_value = np.array([[1, 10], [2, 20]])
        
        # Test that scattering types are properly defined
        assert 'total' in types
        assert 'elastic' in types
        
        # Test file preparation
        with patch('builtins.open'):
            prepare_files(
                file_name='test_integration',
                one_rdm_file='1rdm_test.txt',
                two_rdm_file='2rdm_test.txt',
                molden_file='test.molden',
                type='total'
            )
    
    def test_ci_workflow_integration(self):
        """Test CI coefficient workflow integration."""
        from scat_lib.ci_to_2rdm import write_ci_file
        
        # Mock CASSCF object
        mock_casscf = Mock()
        mock_casscf.ci = np.array([[0.9, 0.1], [0.3, 0.7]])
        mock_casscf.fcisolver = Mock()
        mock_casscf.fcisolver.large_ci = Mock()
        
        with patch('builtins.open'), \
             patch('scat_lib.ci_to_2rdm.fci') as mock_fci:
            mock_fci.cistring.gen_occslst.return_value = np.array([[0, 1], [0, 2]])
            
            # This should not raise an exception
            write_ci_file('test_integration', mock_casscf, (2, 2), 4)
    
    def test_data_flow_consistency(self):
        """Test consistency of data flow between modules."""
        from scat_lib.molecule import Atom
        from scat_lib.rdm_tools import _make_rdm12_on_mo
        
        # Create atoms with consistent data
        h2_atoms = [
            Atom(atmnum=1, x=0.0, y=0.0, z=0.0),
            Atom(atmnum=1, x=0.0, y=0.0, z=1.4)
        ]
        
        # Create RDM data that should be consistent with H2
        ncore, ncas, nmo = 0, 2, 2  # Minimal basis for H2
        casdm1 = np.array([[1.0, 0.0], [0.0, 1.0]])  # Two electrons in two orbitals
        casdm2 = np.zeros((ncas, ncas, ncas, ncas))
        
        dm1, dm2 = _make_rdm12_on_mo(casdm1, casdm2, ncore, ncas, nmo)
        
        # Verify data consistency
        assert len(h2_atoms) == 2  # Two H atoms
        assert dm1.shape[0] == nmo   # RDM matches orbital count
        assert np.trace(dm1) == 2    # Two electrons total
    
    def test_error_propagation(self):
        """Test that errors propagate correctly through the workflow."""
        from scat_lib.rdm_tools import _make_rdm12_on_mo
        
        # Test with incompatible dimensions
        with pytest.raises((ValueError, IndexError)):
            ncore, ncas, nmo = 2, 4, 3  # nmo < ncore + ncas
            casdm1 = np.eye(ncas)
            casdm2 = np.zeros((ncas, ncas, ncas, ncas))
            _make_rdm12_on_mo(casdm1, casdm2, ncore, ncas, nmo)
    
    def test_numerical_precision(self):
        """Test numerical precision across modules."""
        from scat_lib.rdm_tools import _make_rdm12_on_mo
        
        ncore, ncas, nmo = 1, 2, 4
        casdm1 = np.array([[0.333333333, 0.1], [0.1, 0.666666667]])
        casdm2 = np.zeros((ncas, ncas, ncas, ncas))
        
        dm1, dm2 = _make_rdm12_on_mo(casdm1, casdm2, ncore, ncas, nmo)
        
        # Check that numerical precision is maintained
        assert np.allclose(dm1[ncore:ncore+ncas, ncore:ncore+ncas], casdm1)
        assert dm1[0, 0] == 2.0  # Core electron contribution should be exact
    
    def test_memory_efficiency(self):
        """Test memory efficiency for larger systems."""
        from scat_lib.rdm_tools import _make_rdm12_on_mo
        
        # Test with moderately sized system
        ncore, ncas, nmo = 5, 10, 20
        casdm1 = np.random.rand(ncas, ncas)
        casdm2 = np.random.rand(ncas, ncas, ncas, ncas)
        
        dm1, dm2 = _make_rdm12_on_mo(casdm1, casdm2, ncore, ncas, nmo)
        
        # Verify shapes without excessive memory usage
        assert dm1.shape == (nmo, nmo)
        assert dm2.shape == (nmo, nmo, nmo, nmo)
        
        # Cleanup
        del dm1, dm2, casdm1, casdm2