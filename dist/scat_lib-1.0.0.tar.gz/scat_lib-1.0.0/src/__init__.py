"""
Bundled Fortran sources for scat_lib.

The files in this package are treated as data assets and are used by
`scat_lib.build` when recompiling binaries on demand.
"""
